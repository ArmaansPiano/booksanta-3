import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import WelcomeScreen from './Screens/welcomeScreen';

export default function App() {
  return (
    <WelcomeScreen/>
  );
}